<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 xl:w-11/12">
            <div class="py-3 text-center">
                <h1 class="text-4xl font-bold font-mono">Debes cumplir con este reto para obtener tu vida adicional,
                    tomate tu tiempo y hazlo al pie de la letra</h1>
            </div>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 ">

                    <p> Debes grabar un audio en WhatsApp con duracion minima de 30 segundos en donde digas lo que quieras
                        y como quieras pero con una ¡CONDICIÓN! en el audio debes decir estas frases al pie de la letra
                        con un tono muy sexy:
                    </p>
                    <ul class="py-2">
                        <li>* Cuando pienso en tu pene, me exito demasiado y deseo que me penetres</li>
                        <li>* Quiero que me chupes las tetas y con tu lengua lamas mis pezones</li>
                        <li>* Me encanta que me llenes de semen la boca y luego seguir chupandotelo</li>
                    </ul>

                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\pipe\OneDrive\Escritorio\mile\resources\views/retos/1.blade.php ENDPATH**/ ?>