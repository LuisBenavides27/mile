<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 xl:w-11/12">
            <div class="py-3 text-center">
                <h1 class="text-4xl font-bold font-mono">ESTE ES EL NIVEL 2</h1>
            </div>
            <?php if(session('danger')): ?>
                <div class="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400">
                    <strong>
                        <?php echo e(session('danger')); ?>

                    </strong>
                </div>
            <?php endif; ?>
            <?php if(session('info')): ?>
                <div class="p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400">
                    <strong>
                        <?php echo e(session('info')); ?>

                    </strong>
                </div>
            <?php endif; ?>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 lg:flex lg:items-center">


                    <div class="grid grid-cols-12 gap-4">

                        <!-- Column -->
                        <div class="col-span-12 md:col-span-8">
                            <img src="<?php echo e(asset('img/rat.jpg')); ?>" class="max-w-full h-auto">
                        </div>

                        <!-- Column -->
                        
                        <div class="py-12 px-12 col-span-12 md:col-span-4 text-center relative">
                            <h1 class="text-xl mb-4">Debes investigar un poco, ¿ En que año se estreno la pelicula
                                "Ratatoullie" ?</h1>
                        
                            <form action="<?php echo e(route('niveluno')); ?>" class="mt-4" method="POST">
                                <?php echo csrf_field(); ?>
                        
                                <input type="hidden" name="nivel" value="2">
                                <input name="resultado" type="number" class="ml-2 px-2 py-1 border border-gray-400"
                                    required>
                                <br><br><br>
                                <input type="submit" value="VERIFICAR"
                                    class="px-6 py-3.5 my-4 text-base font-medium text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                            </form>
                        
                            <div  class="absolute bottom-4 left-0 right-0 text-red-600 text-sm text-center">Recuerda que si te equivocas pierdes una vida, con cada acierto sumaras 1 punto</div>
                        </div>     



                    </div>


                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\pipe\OneDrive\Escritorio\mile\resources\views/nivels/nivel2.blade.php ENDPATH**/ ?>