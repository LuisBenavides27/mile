<x-app-layout>
    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 xl:w-11/12">
            <div class="py-3 text-center">
                <h1 class="text-4xl font-bold font-mono">Debes cumplir con este reto para obtener tu vida adicional,
                    tomate tu tiempo y hazlo al pie de la letra</h1>
            </div>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 ">

                    <p> Debes tomarte entre 3 y 5 fotos y enviarlas por WhatsApp de la siguiente forma :
                    </p>
                    <ul class="py-2">
                        <li>* Una foto en donde se vea medio cuerpo en bra y lanzando un besito</li>
                        <li>* Una foto en donde estes sin bra pero con con los dedos indices tapandote los pezones </li>
                        <li>* Una foto sin bra usando tus manos para apretar levemente a los lados de tus tetas para que se vean juntas pegadas y deliciosas jeje</li>
                    </ul>

                </div>
            </div>
        </div>
    </div>

</x-app-layout>