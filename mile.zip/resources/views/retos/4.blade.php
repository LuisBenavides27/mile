<x-app-layout>
    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 xl:w-11/12">
            <div class="py-3 text-center">
                <h1 class="text-4xl font-bold font-mono">Debes cumplir con este reto para obtener tu vida adicional,
                    tomate tu tiempo y hazlo al pie de la letra</h1>
            </div>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 ">

                    <p> Debes buscar un video porno que dure MINIMO 5 minutos, este video debe ser un poco diferente a lo que ya hemos hecho sexualmente
                    </p>
                    <ul class="py-2">
                        <li>* Debes aprenderte TODO del video, cada palabra, movimiento o pocision </li>
                        <li>* Debes tomar la inicativa para recrear dicho video, tu decides cuando pero hazlo sin avisar </li>
                        <li>* Recuerda que este video debe ser interesante y diferente y lo mas importante muy sucio jejeje </li>
                    </ul>

                </div>
            </div>
        </div>
    </div>

</x-app-layout>