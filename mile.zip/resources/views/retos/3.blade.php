<x-app-layout>
    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 xl:w-11/12">
            <div class="py-3 text-center">
                <h1 class="text-4xl font-bold font-mono">Debes cumplir con este reto para obtener tu vida adicional,
                    tomate tu tiempo y hazlo al pie de la letra</h1>
            </div>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 ">

                    <p> Esta vez puedes elegir solo una entre una de las siguientes opciones, pero deben durar minimo 5 minutos:
                    </p>
                    <ul class="py-2">
                        <li>* Debes masturbar a tu rrr unicamente usando tus deliciosos pechos</li>
                        <li>* Debes lamer al señor feliz pero unicamente usando la lengua y nada mas </li>
                        <li>* Debes dejarte lamer, besar y chupar tus tetas </li>
                    </ul>

                </div>
            </div>
        </div>
    </div>

</x-app-layout>